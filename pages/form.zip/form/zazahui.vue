<template name="za-za-hui" >
	<view>
		<view>type:{{type}}</view>
	   <view>大家好，我是渣渣辉</view>
	   <input placeholder="这是一个可以自动聚焦的input,我咋x-form组件里面"></input> 
	</view>	
</template>

<script>
	export default {
		name: "zaZaHui",
		props:{
			type:{
				type: String,
				default:"默认type",
				required:true
			}
		}
	}
</script>


