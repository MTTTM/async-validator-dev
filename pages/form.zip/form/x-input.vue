<template>
	<view>
	   <view>input自定义组件:==:{{type}}</view>
	   <input class="uni-input"  />
		<view class="booleen-x-input"  >
			<input class="uni-input"  :type="type" :value="value" :placeholder="placeholder" @input="onChange" @blur='onBlur'
			 :disabled="disabled"  />
			<view class="booleen-x-error" v-if="errorTxt&&errorField==prop">{{errorTxt}}</view>
		</view>
	</view>	
</template>
<script>
	export default {
		name: "x-input",
		props: {
			type: {
				type: String,
				default:()=>{
					return "text";
				}
			},
			value: {
				type: [String, Number],
			},
			prop: {
				type: String
			},
			placeholder: {
				type: String,
				default: "请输入"
			},
			disabled: {
				type: Boolean,
				default: () => {
					return false;
				}
			}
		}
	}
</script>
